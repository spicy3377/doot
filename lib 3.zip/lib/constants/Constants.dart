class DefaultMessages{

  emptyMessage({required String about}){
    return "Opps, No ${about}s to display";
  }
}